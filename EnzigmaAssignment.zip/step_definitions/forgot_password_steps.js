const { Given, When, Then } = require('@cucumber/cucumber');
const { Builder, By, until } = require('selenium-webdriver');
const chai = require('chai');

const expect = chai.expect;
let driver;

Given('I am on the login page', async function () {
    driver = await new Builder().forBrowser('chrome').build();
    try {
        await driver.get('https://app-staging.nokodr.com/super/apps/auth/v1/index.html#/login');
    } catch (error) {
        console.error('Error navigating to the login page:', error);
        throw error;
    }
});

When('I click on the forgot password link', { timeout: 100000 }, async function () {
    console.log("Waiting for the Forgot Password link...");
    const forgotPasswordLink = await driver.wait(
        until.elementLocated(By.xpath("(//a[normalize-space()='Forgot Password?'])[1]")),
        100000
    );
    console.log("Clicking the Forgot Password link...");
    await forgotPasswordLink.click();
});


When('I click on Proceed button', { timeout: 100000 }, async function () {
    const buttonElement = await driver.wait(
        until.elementLocated(By.xpath("//abx-button[@name='proceed']")),
        100000
    );
    console.log("Clicking the Forgot Password link...");
    await buttonElement.click();
});
When('I enter an email {string}', { timeout: 100000 }, async function (text) {
    console.log("Waiting for email field...");
    await driver.wait(until.elementLocated(By.xpath("//abx-modal//input[@type='email']")), 10000);
    const emailField = await driver.findElement(By.xpath("//abx-modal//input[@type='email']"));
    console.log("Entering email...");
    await emailField.clear();
    await emailField.sendKeys(text);
});

When('I enter an email and click the process button', async function () {
    await driver.wait(until.elementLocated(By.xpath("//iframe")), 10000);
    const iframe = await driver.findElement(By.xpath("//iframe"));
    await driver.switchTo().frame(iframe);

    console.log("Locating email field...");
    const emailField = await driver.findElement(By.xpath("//input[@id='id_1736357242081261']"));
    await emailField.clear();
    // await emailField.sendKeys('test@example.com');

    console.log("Locating process button...");
    const processButton = await driver.findElement(By.xpath("//abx-button[2]/button"));
    await processButton.click();

    await driver.switchTo().defaultContent();
});

Then('I should see a message {string}', { timeout: 100000 }, async function (expectedMessage) {
    const alertElement = await driver.wait(until.elementLocated(By.xpath('//abx-toaster//h2')), 10000);
    const alertMessage = await alertElement.getText();
    expect(alertMessage).to.equal(expectedMessage);
    await driver.quit();
});
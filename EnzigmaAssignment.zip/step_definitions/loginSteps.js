const { Given, When, Then } = require('@cucumber/cucumber');
const { Builder, By, until } = require('selenium-webdriver');
const chai = require('chai');
const expect = chai.expect;

let driver;

Given('I am on the login page of noKodr', async function () {
    driver = await new Builder().forBrowser('chrome').build();
    try {
        await driver.get('https://app-staging.nokodr.com/super/apps/auth/v1/index.html#/login');
    } catch (error) {
        console.error('Error navigating to the login page:', error);
        throw error;
    }
});

When('I enter a valid username {string}', async function (username) {
    const usernameField = await driver.wait(
        until.elementLocated(By.xpath("//input[@name='username']")), 10000);
    await usernameField.clear();
    await usernameField.sendKeys(username);
});

When('I enter a valid password {string}', async function (password) {
    const passwordField = await driver.wait(
        until.elementLocated(By.xpath("//input[@type='password']")), 10000);
    await passwordField.clear();
    await passwordField.sendKeys(password);
});

When('I click on the Sign In button',{ timeout: 100000 }, async function () {
    const signInButton = await driver.wait(
        until.elementLocated(By.xpath("//div[@id='staticElement' and @class='slds-truncate' and text()='Log In']")), 10000);
    await signInButton.click();
});

Then('I should be logged in and see the dashboard', { timeout: 100000 }, async function () {
    const dashboardElement = await driver.wait(
        until.elementLocated(By.xpath("(//a[@class='slds-nav-vertical__action slds-anchor_height'])[1]")), 10000);
    
    expect(await dashboardElement.isDisplayed()).to.be.true;
    await driver.quit();
});


Then('I see a message {string}', { timeout: 100000 }, async function (expectedMessage) {
    const alertElement = await driver.wait(until.elementLocated(By.xpath('//abx-toaster//h2')), 10000);
    const alertMessage = await alertElement.getText();
    expect(alertMessage).to.equal(expectedMessage);
    await driver.quit();
});
const { Given, When, Then } = require('@cucumber/cucumber');
const { Builder, By, until } = require('selenium-webdriver');  
const SignupPage = require('../pages/SignupPage'); 

const chai = require('chai');
const expect = chai.expect;
let driver;
let signupPage;

Given('I am on the login pages', async function () {
    driver = await new Builder().forBrowser('chrome').build();
    try {
        await driver.get('https://app-staging.nokodr.com/super/apps/auth/v1/index.html#/login');
    } catch (error) {
        console.error('Error navigating to the login page:', error);
        throw error;
    }
});

When('I click on the Signup link', { timeout: 100000 }, async function () {
    console.log("Waiting for the Signup link...");
    const signupLink = await driver.wait(
        until.elementLocated(By.xpath("(//a[normalize-space()='Sign up'])[1]")),
        100000
    );
    console.log("Clicking the Signup link...");
    
    await signupLink.click();
});

When('I enter a valid email {string}', { timeout: 1000000 }, async function (text) {
    console.log("Waiting for email field...");
    await driver.wait(until.elementLocated(By.xpath("//abx-modal//input[@type='email']")), 10000);
    const emailField = await driver.findElement(By.xpath("//abx-modal//input[@type='email']"));
    console.log("Entering email...");
    await emailField.clear();
    await emailField.sendKeys(text);
});

When('I agree to the Terms and Conditions',{ timeout: 100000 }, async function () {
    const termsCheckbox = await driver.wait(
      until.elementLocated(By.xpath("(//span[@class='slds-checkbox_faux'])[1]")),
      10000
    );
    await termsCheckbox.click();  
  });
  

When('I click on the Sign Up button', { timeout: 100000 }, async function () {
    const buttonElement = await driver.wait(
        until.elementLocated(By.xpath("//abx-button[@label='Proceed']")),
        100000
    );
    console.log("Clicking the signup button...");
    await buttonElement.click();
});

Then('I should see a messages {string}', async function (expectedMessage) {
    const alertElement = await driver.wait(until.elementLocated(By.xpath('//abx-toaster//h2')), 10000);
    const alertMessage = await alertElement.getText();
    expect(alertMessage).to.equal(expectedMessage);
    await driver.quit();
});

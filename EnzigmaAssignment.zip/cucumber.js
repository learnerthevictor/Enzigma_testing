module.exports = {
    default: `--require step_definitions/**/*.js --require pages/**/*.js --format progress`,
    timeout: 10000
};

const { By } = require('selenium-webdriver');

class ForgotPasswordPage {
    constructor(driver) {
        this.driver = driver;
    }

    async visit() {
        await this.driver.get('https://app-staging.nokodr.com/forgot-password');
    }

    async enterEmail(email) {
        await this.driver.findElement(By.id('email')).sendKeys(email);
    }

    async submit() {
        await this.driver.findElement(By.id('submit')).click();
    }

    async getAlertMessage() {
        return await this.driver.findElement(By.css('.alert')).getText();
    }
}

module.exports = ForgotPasswordPage;

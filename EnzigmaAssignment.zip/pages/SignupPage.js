const { By, until } = require('selenium-webdriver');

class SignupPage {
    constructor(driver) {
        this.driver = driver;
        this.emailField = "//input[@type='email']";           
        this.passwordField = "//input[@type='password']";     
        this.confirmPasswordField = "//input[@name='confirmPassword']"; 
        this.signUpButton = "//button[text()='Sign Up']";     
        this.alertMessage = "//div[@class='alert-message']";  
    }

    async visit() {
        await this.driver.get('https://app-staging.nokodr.com/super/apps/auth/v1/index.html#/login');
    }

    async enterEmail(email) {
        await driver.wait(until.elementLocated(By.xpath("//abx-modal//input[@type='email']")), 10000);
        const emailField = await driver.findElement(By.xpath("//abx-modal//input[@type='email']"));
        const emailInput = await this.driver.wait(
            until.elementLocated(By.xpath(emailFieldXPath)),
            10000
        );
        await emailField.clear();
        await emailField.sendKeys(email);
    }
    
    

    async enterPassword(password) {
        const passwordInput = await this.driver.wait(
            until.elementLocated(By.xpath(this.passwordField)),
            10000
        );
        await passwordInput.clear();
        await passwordInput.sendKeys(password);
    }

    async enterConfirmPassword(password) {
        const confirmPasswordInput = await this.driver.wait(
            until.elementLocated(By.xpath(this.confirmPasswordField)),
            10000
        );
        await confirmPasswordInput.clear();
        await confirmPasswordInput.sendKeys(password);
    }

    async clickSignUpButton() {
        const signUpButton = await this.driver.wait(
            until.elementLocated(By.xpath(this.signUpButton)),
            10000
        );
        await signUpButton.click();
    }

    async getAlertMessage() {
        const alert = await this.driver.wait(
            until.elementLocated(By.xpath(this.alertMessage)),
            10000
        );
        return await alert.getText();
    }
}

module.exports = SignupPage;
